"""Schmale lokale HTTP-Brücke zu den bestehenden STORYFORGE-Verfahren."""

import json
import threading
from urllib.parse import urlsplit
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from uuid import UUID, uuid4

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from storyforge.pilot import PilotConfig, PilotLab, PilotRating

from storyforge import (Analysebereich, Arbeitsweise, Autorenredaktion, ConflictError, Dialogue,
                        FakeProvider, Geheimnislabor, Idea, Memory, NarrativeLibrary, NotFoundError, OllamaProvider,
                        Operation, Quelle, Snapshot, Stoffschmiede)
from .ollama_service import OllamaService, local_models

STATIC = Path(__file__).parent / "static"
CARDS = Path.cwd() / "library" / "cards"


class ProjectInput(BaseModel):
    title: str = Field(min_length=1)
    universe_title: str | None = None


class BranchInput(BaseModel):
    name: str = Field(min_length=1)
    from_revision_id: UUID


class JobInput(BaseModel):
    project_id: UUID
    branch_id: UUID
    procedure: str
    task: str = Field(min_length=1)
    model: str = Field(min_length=1)
    options: dict = Field(default_factory=dict)


class ApproveInput(BaseModel):
    author: str = Field(min_length=1)
    explicit_approval: bool


class AppService:
    def __init__(self, database: Path, library: Path = CARDS, provider_factory=OllamaProvider,
                 pilot_provider_factory=None, pilot_cases=None):
        self.memory = Memory(database)
        self.library = NarrativeLibrary.load(library)
        self.provider_factory = provider_factory
        self.pilot = PilotLab(database.with_name(database.stem + "-pilot.sqlite3"),
                              pilot_provider_factory or (lambda model, params: OllamaProvider(model, options=params)),
                              cards=library, **({"cases": pilot_cases} if pilot_cases else {}))
        self.executor = ThreadPoolExecutor(max_workers=3, thread_name_prefix="storyforge")
        self.jobs: dict[str, dict] = {}
        self.lock = threading.Lock()

    def launch(self, request: JobInput) -> str:
        if request.procedure not in {"V01", "V02", "V03", "V04", "V05"}:
            raise ValueError("Unbekanntes Verfahren")
        branch = next((b for b in self.memory.list_branches(request.project_id)
                       if b.id == request.branch_id), None)
        if branch is None:
            raise NotFoundError(request.branch_id)
        job_id = str(uuid4())
        cancel = threading.Event()
        with self.lock:
            self.jobs[job_id] = {"id": job_id, "project_id": str(request.project_id),
                                 "branch_id": str(request.branch_id), "status": "läuft",
                                 "cancel": cancel, "result": None, "error": None}
        self.executor.submit(self._work, job_id, request)
        return job_id

    def _work(self, job_id: str, request: JobInput):
        with self.lock:
            job = self.jobs[job_id]
        try:
            provider = self.provider_factory(request.model)
            options = request.options
            source_note = self._source_note(request)
            task = request.task + source_note
            if request.procedure == "V01":
                def on_chunk(part):
                    with self.lock:
                        job["partial"] = job.get("partial", "") + part

                result = Dialogue(self.memory, provider).ask(request.project_id, request.branch_id,
                                                              task, cancel=job["cancel"],
                                                              on_chunk=on_chunk)
                payload = {"answer": result.answer, "manifest": result.manifest, "model": result.model,
                           "duration_seconds": result.duration_seconds,
                           "wall_seconds": result.wall_seconds, "output_tokens": result.output_tokens,
                           "generation_tokens_per_second": result.generation_tokens_per_second}
            elif request.procedure == "V02":
                run = Stoffschmiede(self.memory, provider, self.library).develop(
                    request.project_id, request.branch_id, task,
                    count=int(options.get("count", 3)), reflect=bool(options.get("reflect", False)),
                    cancel=job["cancel"])
                payload = {"run_id": str(run.id), "candidates": [c.model_dump(mode="json")
                           for c in run.candidates], "reflection": run.reflection.model_dump(mode="json")
                           if run.reflection else None, "manifest": run.manifest}
            elif request.procedure == "V03":
                run = Geheimnislabor(self.memory, provider, self.library).develop(
                    request.project_id, request.branch_id, task,
                    mode=Arbeitsweise(options.get("mode", "rueckwaerts")),
                    given_truth=options.get("given_truth"), cancel=job["cancel"])
                payload = {"run_id": str(run.id), "result": run.entwurf.model_dump(mode="json"),
                           "manifest": run.manifest}
            else:
                source = Quelle.model_validate(options.get("source", {"art": "frei", "beschreibung": request.task}))
                editor = Autorenredaktion(self.memory, provider, self.library)
                if request.procedure == "V04":
                    run = editor.mutate(request.project_id, request.branch_id, task, source,
                                        operation=Operation(options.get("operation", "frei")),
                                        erhalten=tuple(options.get("erhalten", [])),
                                        veraenderbar=tuple(options.get("veraenderbar", [])),
                                        gezielt_aendern=tuple(options.get("gezielt_aendern", [])),
                                        moeglichkeiten=tuple(options.get("moeglichkeiten", [])),
                                        cancel=job["cancel"])
                else:
                    areas = tuple(Analysebereich(value) for value in options.get("bereiche", list(Analysebereich)))
                    run = editor.critique(request.project_id, request.branch_id, task, source,
                                          bereiche=areas, cancel=job["cancel"])
                payload = {"run_id": str(run.id), "result": run.result.model_dump(mode="json"),
                           "manifest": run.manifest}
            with self.lock:
                job["status"] = "fertig"
                job["result"] = payload
        except Exception as error:
            with self.lock:
                job["status"] = "abgebrochen" if job["cancel"].is_set() else "fehler"
                job["error"] = f"{type(error).__name__}: {error}"

    def _source_note(self, request: JobInput) -> str:
        options = request.options
        turn_id = options.get("source_turn_id")
        run_id = options.get("source_run_id")
        if turn_id and run_id:
            raise ValueError("Nur eine Ausgangsquelle zulässig")
        if options.get("source_candidate_id") and not run_id:
            raise ValueError("Kandidat ohne kreatives Ausgangsergebnis")
        if run_id and request.procedure not in {"V01", "V03"}:
            raise ValueError("Kreative Folgequelle ist hier nicht zulässig")
        branch = next(b for b in self.memory.list_branches(request.project_id)
                      if b.id == request.branch_id)
        if turn_id:
            turn = self.memory.get_turn(UUID(turn_id), request.project_id, request.branch_id)
            if turn["revision_id"] != str(branch.head_id):
                raise ConflictError("Gesprächsquelle basiert auf einer veralteten Revision")
            if turn["role"] != "assistant":
                raise ValueError("Nur KI-Gesprächsbeiträge als Quelle verwenden")
            source = options.get("source")
            if source and request.procedure not in {"V04", "V05"}:
                raise ValueError("Gesprächsquelle ist hier nicht zulässig")
            if source and source.get("beschreibung") != turn["content"]:
                raise ValueError("Gesprächsquelle wurde verändert")
            return f"\nAusgewählter Gesprächsbeitrag:\n{turn['content']}" if not source else \
                   "\nAusgewählter Gesprächsbeitrag als Ausgangsmaterial."
        if run_id:
            run = self.memory.get_creative_run(UUID(run_id))
            if (run["project_id"], run["branch_id"]) != (str(request.project_id), str(request.branch_id)):
                raise NotFoundError(run_id)
            if run["revision_id"] != str(branch.head_id):
                raise ConflictError("Kreative Quelle basiert auf einer veralteten Revision")
            candidate_id = options.get("source_candidate_id")
            candidates = run["candidates"]
            if candidate_id:
                candidates = [item for item in candidates if item.get("id") == candidate_id]
                if not candidates:
                    raise NotFoundError(candidate_id)
            return "\nAusgewähltes kreatives Ergebnis:\n" + json.dumps(candidates, ensure_ascii=False)
        return ""

    def state(self, job_id: str) -> dict:
        with self.lock:
            job = self.jobs.get(job_id)
            if job is None:
                raise NotFoundError(job_id)
            return {key: value for key, value in job.items() if key != "cancel"}

    def cancel(self, job_id: str):
        with self.lock:
            job = self.jobs.get(job_id)
            if job is None:
                raise NotFoundError(job_id)
            job["cancel"].set()
            if job["status"] == "läuft":
                job["status"] = "abbruch angefordert"

    def launch_pilot(self, group_id: str, arm: str, repetition: int) -> str:
        job_id = str(uuid4())
        cancel = threading.Event()
        with self.lock:
            self.jobs[job_id] = {"id": job_id, "status": "läuft", "cancel": cancel,
                                 "result": None, "error": None}

        def work():
            try:
                self.pilot.execute(group_id, arm, repetition, cancel)
                with self.lock:
                    self.jobs[job_id]["status"] = "fertig"
                    self.jobs[job_id]["result"] = {"saved": True}
            except Exception as error:
                with self.lock:
                    self.jobs[job_id]["status"] = "abgebrochen" if cancel.is_set() else "fehler"
                    self.jobs[job_id]["error"] = f"{type(error).__name__}: {error}"

        self.executor.submit(work)
        return job_id


def create_app(database: Path, library: Path = CARDS, provider_factory=OllamaProvider,
               pilot_provider_factory=None, pilot_cases=None, ollama_service: OllamaService | None = None,
               shutdown_callback=None) -> FastAPI:
    service = AppService(database, library, provider_factory, pilot_provider_factory, pilot_cases)
    app = FastAPI(title="STORYFORGE", docs_url=None, redoc_url=None, openapi_url=None)
    app.state.service = service

    @app.middleware("http")
    async def local_only(request: Request, call_next):
        host = request.headers.get("host", "").split(":")[0].strip("[]")
        origin = request.headers.get("origin")
        if host not in {"127.0.0.1", "localhost", "testserver"}:
            return PlainTextResponse("Nur lokale Zugriffe erlaubt", status_code=403)
        parsed = urlsplit(origin) if origin else None
        if parsed and (parsed.scheme != "http" or parsed.netloc != request.headers.get("host")):
            return PlainTextResponse("Fremde Herkunft abgelehnt", status_code=403)
        response = await call_next(request)
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; "
            "connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'"
        )
        response.headers["X-Content-Type-Options"] = "nosniff"
        return response

    @app.exception_handler(ValueError)
    async def value_error(_request, error):
        return PlainTextResponse(str(error), status_code=409 if isinstance(error, ConflictError) else 400)

    @app.exception_handler(NotFoundError)
    async def missing(_request, error):
        return PlainTextResponse(f"Nicht gefunden: {error}", status_code=404)

    @app.exception_handler(KeyError)
    async def missing_key(_request, error):
        return PlainTextResponse(f"Nicht gefunden: {error}", status_code=404)

    @app.exception_handler(PermissionError)
    async def permission(_request, error):
        return PlainTextResponse(str(error), status_code=403)

    app.mount("/static", StaticFiles(directory=STATIC), name="static")

    @app.get("/")
    def index():
        return FileResponse(STATIC / "index.html")

    @app.get("/api/projects")
    def projects():
        return [p.model_dump(mode="json") for p in service.memory.list_projects()]

    @app.post("/api/projects")
    def create_project(data: ProjectInput):
        return service.memory.create_project(data.title, universe_title=data.universe_title).model_dump(mode="json")

    @app.get("/api/projects/{project_id}")
    def project(project_id: UUID):
        p = service.memory.get_project(project_id)
        branches = service.memory.list_branches(project_id)
        return {"project": p.model_dump(mode="json"),
                "branches": [b.model_dump(mode="json") for b in branches],
                "revisions": [service.memory.get_revision(b.head_id).model_dump(mode="json") for b in branches]}

    @app.post("/api/projects/{project_id}/branches")
    def create_branch(project_id: UUID, data: BranchInput):
        return service.memory.create_branch(project_id, data.name, data.from_revision_id).model_dump(mode="json")

    @app.get("/api/projects/{project_id}/runs")
    def runs(project_id: UUID, branch_id: UUID | None = None):
        return service.memory.list_creative_runs(project_id, branch_id)

    @app.get("/api/projects/{project_id}/revisions")
    def revisions(project_id: UUID):
        return [r.model_dump(mode="json") for r in service.memory.list_revisions(project_id)]

    @app.get("/api/runs/{run_id}")
    def run(run_id: UUID):
        return service.memory.get_creative_run(run_id)

    @app.get("/api/projects/{project_id}/proposals")
    def proposals(project_id: UUID, branch_id: UUID | None = None):
        return [p.model_dump(mode="json") for p in service.memory.list_proposals(project_id, branch_id)]

    @app.post("/api/runs/{run_id}/candidates/{candidate_id}/stage")
    def stage(run_id: UUID, candidate_id: UUID):
        proposal = Stoffschmiede(service.memory, FakeProvider([]), service.library).stage_candidate(
            run_id, candidate_id)
        return proposal.model_dump(mode="json")

    @app.post("/api/proposals/{proposal_id}/approve")
    def approve(proposal_id: UUID, data: ApproveInput):
        return service.memory.approve(proposal_id, approved_by=data.author,
                                      explicit_approval=data.explicit_approval).model_dump(mode="json")

    @app.post("/api/proposals/{proposal_id}/reject")
    def reject(proposal_id: UUID):
        service.memory.reject(proposal_id)
        return {"status": "abgelehnt"}

    @app.get("/api/projects/{project_id}/turns")
    def turns(project_id: UUID, branch_id: UUID):
        return service.memory.list_turns(project_id, branch_id, limit=None)

    @app.post("/api/turns/{turn_id}/stage")
    def stage_turn(turn_id: UUID, project_id: UUID, branch_id: UUID):
        turn = service.memory.get_turn(turn_id, project_id, branch_id)
        if turn["role"] != "assistant":
            raise ValueError("Nur KI-Gesprächsbeiträge können als Idee vorgemerkt werden")
        branch = next((b for b in service.memory.list_branches(project_id) if b.id == branch_id), None)
        if branch is None:
            raise NotFoundError(branch_id)
        if turn["revision_id"] != str(branch.head_id):
            raise ConflictError("Gesprächsbeitrag basiert auf einer veralteten Revision")
        base = service.memory.get_revision(branch.head_id)
        idea = Idea(id=uuid4(), title="Idee aus Gespräch", premise=turn["content"],
                    mechanism="Im Gespräch entwickelt")
        snapshot = Snapshot(ideas=[*base.snapshot.ideas, idea], decisions=base.snapshot.decisions)
        return service.memory.propose(branch_id, branch.head_id, snapshot,
                                      "Gesprächsidee vormerken").model_dump(mode="json")

    @app.get("/api/projects/{project_id}/export/{format}")
    def export(project_id: UUID, format: str):
        if format == "json":
            return PlainTextResponse(service.memory.export_json(project_id), media_type="application/json")
        if format == "markdown":
            return PlainTextResponse(service.memory.export_markdown(project_id), media_type="text/markdown")
        raise ValueError("Unbekanntes Exportformat")

    @app.get("/api/models")
    def models():
        if ollama_service is not None:
            return ollama_service.status()
        try:
            return {"online": True, "models": local_models()}
        except (OSError, ValueError, KeyError, TypeError):
            return {"online": False, "models": []}

    @app.post("/api/shutdown")
    def shutdown():
        if shutdown_callback is None:
            return PlainTextResponse("Beenden nur im gestarteten STORYFORGE verfügbar", status_code=503)
        with service.lock:
            for job in service.jobs.values():
                job["cancel"].set()
        shutdown_callback()
        return {"status": "STORYFORGE wird beendet"}

    @app.post("/api/jobs")
    def start_job(data: JobInput):
        return {"id": service.launch(data)}

    @app.get("/api/jobs/{job_id}")
    def job(job_id: str):
        return service.state(job_id)

    @app.post("/api/jobs/{job_id}/cancel")
    def cancel(job_id: str):
        service.cancel(job_id)
        return service.state(job_id)

    @app.get("/api/pilot/cases")
    def pilot_cases_list():
        return [case.model_dump() for case in service.pilot.cases.values()]

    @app.post("/api/pilot/groups")
    def pilot_group(config: PilotConfig):
        return {"id": service.pilot.create_group(config)}

    @app.post("/api/pilot/groups/{group_id}/runs")
    def pilot_run(group_id: str, arm: str, repetition: int = 1):
        service.pilot._group(group_id)
        return {"id": service.launch_pilot(group_id, arm, repetition)}

    @app.get("/api/pilot/groups/{group_id}/blind")
    def pilot_blind(group_id: str):
        return service.pilot.blind_runs(group_id)

    @app.post("/api/pilot/ratings/{blind_id}")
    def pilot_rating(blind_id: str, rating: PilotRating):
        service.pilot.rate(blind_id, rating)
        return {"saved": True}

    @app.get("/api/pilot/groups/{group_id}/report")
    def pilot_report(group_id: str, reveal: bool = False):
        return service.pilot.report(group_id, reveal=reveal)

    @app.get("/api/pilot/groups/{group_id}/export/{format}")
    def pilot_export(group_id: str, format: str, reveal: bool = False):
        if format == "json":
            return PlainTextResponse(json.dumps(service.pilot.report(group_id, reveal=reveal),
                                                ensure_ascii=False, indent=2), media_type="application/json")
        if format == "markdown":
            return PlainTextResponse(service.pilot.markdown(group_id, reveal=reveal), media_type="text/markdown")
        raise ValueError("Unbekanntes Exportformat")

    return app
