"""Lokale Browseroberfläche von STORYFORGE."""
